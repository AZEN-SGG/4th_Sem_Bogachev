#ifndef LIST2_NODE_H
#define LIST2_NODE_H

#include "ordering.h"

#include <utility>

template <typename T>
class database;

template <typename T>
class search_structure_store;

template <typename T>
class index_trees;

template <typename T, ordering X>
class data_tree;

template <typename T>
class list2;

template <typename T>
class list2_node : public T
{
	private:
		list2_node * next = nullptr;
		list2_node * prev = nullptr;
		list2_node * link = nullptr; // Mini list in class
	public:
		list2_node () = default;
		~list2_node () { next = nullptr; prev = nullptr; link = nullptr; }

		list2_node (const list2_node&) = delete;
		list2_node (list2_node&& r) : T((T&&)r)
		{
			prev = r.prev;
			r.prev = nullptr;

			next = r.next;
			r.next = nullptr;

			link = r.link;
			r.link = nullptr;
		}

		list2_node& operator= (const list2_node&) = delete;
		list2_node& operator= (list2_node&& r)
		{
			if (this == &r)
				return *this;

			static_cast<T&>(*this) = std::move(static_cast<T&>(r));

			prev = r.prev;
			r.prev = nullptr;

			next = r.next;
			r.next = nullptr;

			link = r.link;
			r.link = nullptr;

			return *this;
		}

		list2_node * get_next () const { return next; }
		list2_node * get_prev () const { return prev; }
		list2_node * get_link () const { return link; }

		void set_next (list2_node *r) { next = r; }
		void set_prev (list2_node *r) { prev = r; }
		void set_link (list2_node *r) { link = r; }

		friend class list2<T>;

		friend class database<T>;
		friend class search_structure_store<T>;
		friend class index_trees<T>;

		template <typename U, ordering X>
		friend class data_tree;
};

#endif // LIST2_NODE_H
